package com.org.dao;
 
 
import java.util.List;

import com.org.model.ShareVO;
 
  
 
 
 
public interface ShareDAO {
 
     
     List<ShareVO> getAllPlayers() ;
   
     
}