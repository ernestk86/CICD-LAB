package com.org.service;
 
 
import java.util.List;

import com.org.model.ShareVO;
 
 
 
 
public interface ShareService {
 
 
List<ShareVO> getAllShares();
}
 